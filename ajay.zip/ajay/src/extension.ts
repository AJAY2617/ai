import * as vscode from 'vscode';
import ollama from 'ollama';

export function activate(context: vscode.ExtensionContext) {
    let decorationType = vscode.window.createTextEditorDecorationType({
        backgroundColor: 'rgba(255, 255, 0, 0.3)',
        borderRadius: '4px'
    });

    let highlightCode = vscode.commands.registerCommand('extension.highlightCode', () => {
        let editor = vscode.window.activeTextEditor;
        if (!editor) { return; }

        let range = editor.document.lineAt(editor.selection.active.line).range;
        editor.setDecorations(decorationType, [range]);
    });

    context.subscriptions.push(highlightCode);

    const provider = new ChatWebviewProvider(context.extensionUri);
    context.subscriptions.push(
        vscode.window.registerWebviewViewProvider(ChatWebviewProvider.viewType, provider)
    );
}

class ChatWebviewProvider implements vscode.WebviewViewProvider {
    public static readonly viewType = "lobs.chatSidebar";
    private _view?: vscode.WebviewView;

    constructor(private readonly extensionUri: vscode.Uri) {}

    public resolveWebviewView(webviewView: vscode.WebviewView) {
        this._view = webviewView;

        webviewView.webview.options = {
            enableScripts: true,
            localResourceRoots: [this.extensionUri]
        };

        webviewView.webview.html = this.getHtml();

        webviewView.webview.onDidReceiveMessage(async (message) => {
            if (message.command === "sendMessage") {
                const response = await processChat(message.text);
                webviewView.webview.postMessage({ command: "receiveMessage", text: response });
            }
        });
    }

    private getHtml(): string {
        return `
        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Chat</title>
    
    <style>
       body {
    font-family: Arial, sans-serif; 
    padding: 10px; 
    background-color: #1e1e1e; 
    color: #dcdcdc; 
    display: flex; 
    flex-direction: column; 
    height: 100vh; 
    margin: 0; 
}

.chat-container { 
    max-width: 100%; 
    flex: 1; /* This makes the chat container take up the remaining space */
    border: 1px solid #3c3c3c; 
    padding: 8px; 
    background-color: #252526; 
    border-radius: 4px; 
}

.input-container { 
    margin-top: 10px; 
    display: flex; 
    align-items: center; 
}

        textarea { flex: 1; padding: 10px; background: #333; color: white; border: 1px solid #555; border-radius: 4px; }
        button { padding: 8px; background: #007acc; color: white; border: none; border-radius: 4px; margin-left: 5px; cursor: pointer; }
        pre { white-space: pre-wrap; word-wrap: break-word; padding: 8px; border-radius: 6px; background: #282c34; color: #abb2bf; overflow-x: auto; }
        code { font-family: monospace; }
        .user-message, .bot-message { display: flex; align-items: center; margin: 5px; }
        .user-message { justify-content: flex-end; }
        .bot-message { justify-content: flex-start; }
        .message-box { padding: 8px 12px; border-radius: 6px; max-width: 80%; display: inline-block; position: relative; }
        .typing-indicator { font-style: italic; color: #bbbbbb; }
         .copy-btn, .edit-btn { background: none; border: none; font-size: 12px; cursor: pointer; color: white; transition: color 0.1s ease-in-out; margin-left: 5px; }
                .copy-btn:hover, .edit-btn:
                .edit-input { background: : white; border: 1px solid #555; border-radius: 4px; padding: 5px; width: 100%; }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/styles/atom-one-dark.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/highlight.min.js"></script>
</head>
<body>
    <h3>AI Chat</h3>
    <div class="chat-container" id="chat"></div>
    <div class="input-container">
        <textarea id="messageInput" placeholder="Type or paste a message..."></textarea>
        <button onclick="sendMessage()">Send</button>
    </div>

    <script>
        const vscode = acquireVsCodeApi();

        function sendMessage() {
            const input = document.getElementById("messageInput");
            const textToSend = input.value.trim();
            if (textToSend !== "") {
                addUserMessage(textToSend);
                showTypingIndicator();
                vscode.postMessage({ command: "sendMessage", text: textToSend });
                input.value = "";
            }
        }
         // Handle Enter and Shift+Enter
                const messageInput = document.getElementById("messageInput");
                messageInput.addEventListener('keydown', function(event) {
                    if (event.key === 'Enter' && !event.shiftKey) {
                        event.preventDefault(); // Prevent new line
                        sendMessage();
                    } else if (event.key === 'Enter' && event.shiftKey) {
                        // Allow new line
                    }
                });    

        function showTypingIndicator() {
            const chat = document.getElementById("chat");
            chat.innerHTML += \`
                <div id="typingIndicator" class="bot-message">
                    <div class="message-box bot-box">
                        <pre class="typing-indicator">Ajay is typing...</pre>
                    </div>
                </div>
            \`;
            chat.scrollTop = chat.scrollHeight;
        }

        function addUserMessage(text) {
                    const chat = document.getElementById("chat");
                    const messageId = "msg-" + Date.now(); // Unique ID for each message
                    const copyBtnId = "copy-btn-" + Date.now(); // Unique ID for copy button
                    const editBtnId = "edit-btn-" + Date.now(); // Unique ID for edit button

                    chat.innerHTML += \`
                        <div class="user-message">
                            <button id="\${editBtnId}" class="edit-btn" onclick="startEditMessage('\${messageId}', '\${editBtnId}')">edit</button>
                            <button id="\${copyBtnId}" class="copy-btn" onclick="copyToClipboard('\${messageId}', '\${copyBtnId}')">copy</button>
                            <div class="message-box user-box">
                                <pre id="\${messageId}">\${text}</pre>
                            </div>
                        </div>
                    \`;
                    // Do not scroll automatically after adding a user message
                }

                function startEditMessage(messageId, editBtnId) {
                    const textElement = document.getElementById(messageId);
                    const editButton = document.getElementById(editBtnId);

                    if (textElement && editButton) {
                        // Replace the message text with an input box
                        const currentText = textElement.innerText;
                        textElement.innerHTML = \`
                            <input type="text" class="edit-input" value="\${currentText}" onkeydown="handleEditInputKeydown(event, '\${messageId}', '\${editBtnId}')">
                        \`;

                        // Change the edit button to a save button
                        editButton.innerHTML = "save";
                        editButton.setAttribute("onclick", \`saveEditedMessage('\${messageId}', '\${editBtnId}')\`);
                    }
                }

                function handleEditInputKeydown(event, messageId, editBtnId) {
                    if (event.key === "Enter") {
                        saveEditedMessage(messageId, editBtnId);
                    }
                }

                function saveEditedMessage(messageId, editBtnId) {
                    const textElement = document.getElementById(messageId);
                    const editButton = document.getElementById(editBtnId);
                    const input = textElement.querySelector(".edit-input");

                    if (textElement && editButton && input) {
                        const newText = input.value.trim();
                        if (newText !== "") {
                            // Replace the input box with the updated message text
                            textElement.innerHTML = newText;

                            // Change the save button back to an edit button
                            editButton.innerHTML = "edit";
                            editButton.setAttribute("onclick", \`startEditMessage('\${messageId}', '\${editBtnId}')\`);

                            // Send the edited message to the AI
                            sendEditedMessageToAI(newText);
                        }
                    }
                }

                function sendEditedMessageToAI(newText) {
                    const chat = document.getElementById("chat");

                    // Remove the previous bot response (if any)
                    const botMessages = chat.getElementsByClassName("bot-message");
                    if (botMessages.length > 0) {
                        botMessages[botMessages.length - 1].remove(); // Remove the last bot message
                    }

                    // Show typing indicator
                    showTypingIndicator();

                    // Send the edited message to the AI
                    vscode.postMessage({ command: "sendMessage", text: newText });

                    // Do not scroll automatically after sending an edited message
                }

                function copyToClipboard(messageId, copyBtnId) {
                    const textElement = document.getElementById(messageId);
                    const copyButton = document.getElementById(copyBtnId);
                    
                    if (textElement) {
                        navigator.clipboard.writeText(textElement.innerText).then(() => {
                            copyButton.innerHTML = "Copied! ✔"; // Change icon to checkmark
                            setTimeout(() => {
                                copyButton.innerHTML = "copy"; // Revert icon after 2 seconds
                            }, 2000);
                        }).catch(err => {
                            console.error("Failed to copy: ", err);
                        });
                    }
                }

   function addBotMessage(text) {
    const typingIndicator = document.getElementById("typingIndicator");
    if (typingIndicator) {
        typingIndicator.remove();
    }

    const chat = document.getElementById("chat");
    const messageHTML = \`
        <div class="bot-message">
            <div class="message-box bot-box">
                <pre><code>\${text}</code></pre>
            </div>
            <button class="copy-btn">Copy</button>
            <span class="copy-confirmation" style="display: none;">Copied! ✔</span>
        </div>
    \`;
    chat.innerHTML += messageHTML;
    chat.scrollTop = chat.scrollHeight;

    // Apply syntax highlighting
    document.querySelectorAll('pre code').forEach((block) => {
        hljs.highlightElement(block);
    });

    // Add copy functionality
    const copyBtns = document.querySelectorAll('.copy-btn');
    copyBtns.forEach((btn) => {
        btn.addEventListener('click', function() {
            const messageBox = this.previousElementSibling;
            const textToCopy = messageBox.innerText;
            const confirmation = this.nextElementSibling;

            navigator.clipboard.writeText(textToCopy)
                .then(() => {
                    confirmation.style.display = "inline";
                    this.style.display = "none"; // Hide the copy button
                    setTimeout(() => {
                        confirmation.style.display = "none";
                        this.style.display = "inline"; // Show the button again
                    }, 2000);
                })
                .catch((err) => {
                    console.error('Error copying text: ', err);
                });
        });
    });
}

        window.addEventListener("message", event => {
            const message = event.data;
            if (message.command === "receiveMessage") {
                addBotMessage(message.text);
            }
        });
    </script>
</body>
</html>
        `;
    }
}

async function processChat(prompt: string): Promise<string> {
    try {
        const response = await ollama.chat({
            "model": "qwen2.5-coder:7b",
            "messages": [{ "role": "user", "content": prompt }]
        });

        return response.message.content || "No response from AI";
    } catch (error) {
        return 'Error: ' + (error as Error).message;
    }
}

export function deactivate() {}