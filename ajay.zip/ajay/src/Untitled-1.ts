import * as vscode from 'vscode';
import ollama from 'ollama';

export function activate(context: vscode.ExtensionContext) {
    const chatProvider = new ChatViewProvider(context);
    const myExtensionContainer = vscode.window.createTreeView('myView', {
        treeDataProvider: chatProvider,
    });

    context.subscriptions.push(myExtensionContainer);

    let chatCommand = vscode.commands.registerCommand('lobs.chatextension', () => {
        vscode.window.showInformationMessage('Chat Extension Activated!');
    });

    context.subscriptions.push(chatCommand);
}

class ChatViewProvider implements vscode.TreeDataProvider<vscode.TreeItem> {
    private _onDidChangeTreeData: vscode.EventEmitter<void> = new vscode.EventEmitter<void>();
    readonly onDidChangeTreeData: vscode.Event<void> = this._onDidChangeTreeData.event;

    private chatHistory: { user: string; response: string }[] = [];
    private currentPrompt: string = '';

    constructor(private context: vscode.ExtensionContext) {}

    getTreeItem(element: vscode.TreeItem): vscode.TreeItem {
        return element;
    }

    getChildren(element?: vscode.TreeItem): Thenable<vscode.TreeItem[]> {
        if (!element) {
            let items: vscode.TreeItem[] = [];

            if (this.chatHistory.length === 0) {
                // Show input box initially (First Image)
                items.push(new InputTreeItem('Ask...', this));
            } else {
                // Show chat history (Second Image)
                for (const chat of this.chatHistory) {
                    items.push(new ChatMessageTreeItem(chat.user, 'user'));
                    items.push(new ChatMessageTreeItem(chat.response, 'bot'));
                }
                items.push(new InputTreeItem('Reply...', this));
            }

            return Promise.resolve(items);
        }
        return Promise.resolve([]);
    }

    async processChat(prompt: string) {
        this.currentPrompt = prompt;
        this._onDidChangeTreeData.fire();

        try {
            let response = "Processing...";
            this.chatHistory.push({ user: prompt, response });

            this._onDidChangeTreeData.fire();

            const streamResponse = await ollama.chat({
                "model": "deepseek-r1:1.5b",
                "messages": [{ "role": "user", "content": prompt }],
                "stream": true
            });

            let fullResponse = "";

            for await (const resp of streamResponse) {
                fullResponse += resp.message.content;
                this.chatHistory[this.chatHistory.length - 1].response = fullResponse;
                this._onDidChangeTreeData.fire();
            }
        } catch (error) {
            const errorMessage = (error as Error).message;
            this.chatHistory[this.chatHistory.length - 1].response = 'Error: ' + errorMessage;
            this._onDidChangeTreeData.fire();
        }
    }
}

// Input field Tree Item
class InputTreeItem extends vscode.TreeItem {
    constructor(label: string, private provider: ChatViewProvider) {
        super(label, vscode.TreeItemCollapsibleState.None);
        this.description = "Type your message...";
        this.command = {
            command: 'extension.inputPrompt',
            title: 'Ask AI',
            arguments: [provider]
        };
    }
}

// Chat Message Display Item
class ChatMessageTreeItem extends vscode.TreeItem {
    constructor(content: string, role: 'user' | 'bot') {
        super(content, vscode.TreeItemCollapsibleState.None);
        this.iconPath = role === 'user' ? new vscode.ThemeIcon('account') : new vscode.ThemeIcon('bot');
    }
}

// Register Commands
vscode.commands.registerCommand('extension.inputPrompt', async (provider: ChatViewProvider) => {
    const input = await vscode.window.showInputBox({ prompt: 'Enter your prompt' });
    if (input) {
        provider.processChat(input);
    }
});

export function deactivate() {}
